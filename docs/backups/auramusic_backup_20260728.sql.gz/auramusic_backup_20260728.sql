-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: auramusic
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.24.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `artists`
--

DROP TABLE IF EXISTS `artists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `artists` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `owner_user_id` bigint DEFAULT NULL,
  `name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bio` text COLLATE utf8mb4_unicode_ci,
  `image_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_artists_owner_name` (`owner_user_id`,`name`),
  KEY `idx_artists_owner_user_id` (`owner_user_id`),
  CONSTRAINT `fk_artists_owner_users` FOREIGN KEY (`owner_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artists`
--

LOCK TABLES `artists` WRITE;
/*!40000 ALTER TABLE `artists` DISABLE KEYS */;
INSERT INTO `artists` VALUES (1,NULL,'Luna Vale','Cantautora de pop atmosferico con sonidos nocturnos.','https://images.auramusic.local/artists/luna-vale.png','2026-07-28 16:48:50','2026-07-28 16:48:50'),(2,NULL,'Neon River','Duo electronico con sintetizadores brillantes y bajos profundos.','https://images.auramusic.local/artists/neon-river.png','2026-07-28 16:48:50','2026-07-28 16:48:50'),(3,NULL,'Atlas Nova','Productor de indie rock espacial y texturas analogas.','https://images.auramusic.local/artists/atlas-nova.png','2026-07-28 16:48:50','2026-07-28 16:48:50'),(4,NULL,'Maya Sol','Vocalista latina con mezcla de soul, pop y ritmos calidos.','https://images.auramusic.local/artists/maya-sol.png','2026-07-28 16:48:50','2026-07-28 16:48:50'),(5,NULL,'Echo Harbor','Proyecto alternativo inspirado en paisajes costeros.','https://images.auramusic.local/artists/echo-harbor.png','2026-07-28 16:48:50','2026-07-28 16:48:50'),(6,NULL,'Velvet North','Banda de rock suave con guitarras ambientales.','https://images.auramusic.local/artists/velvet-north.png','2026-07-28 16:48:50','2026-07-28 16:48:50'),(7,NULL,'Solar Kids','Colectivo juvenil de dance pop y hooks luminosos.','https://images.auramusic.local/artists/solar-kids.png','2026-07-28 16:48:50','2026-07-28 16:48:50'),(8,NULL,'Midnight Bloom','Proyecto dream pop con voces etereas.','https://images.auramusic.local/artists/midnight-bloom.png','2026-07-28 16:48:50','2026-07-28 16:48:50'),(9,NULL,'Rocco Beats','Beatmaker urbano enfocado en trap melodico.','https://images.auramusic.local/artists/rocco-beats.png','2026-07-28 16:48:50','2026-07-28 16:48:50'),(10,NULL,'Aurora Fields','Compositora de folk moderno y arreglos acusticos.','https://images.auramusic.local/artists/aurora-fields.png','2026-07-28 16:48:50','2026-07-28 16:48:50');
/*!40000 ALTER TABLE `artists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `band_members`
--

DROP TABLE IF EXISTS `band_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `band_members` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `band_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `instrument` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `member_role` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `joined_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_band_members_band_user` (`band_id`,`user_id`),
  KEY `idx_band_members_user_id` (`user_id`),
  CONSTRAINT `fk_band_members_bands` FOREIGN KEY (`band_id`) REFERENCES `bands` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_band_members_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `band_members`
--

LOCK TABLES `band_members` WRITE;
/*!40000 ALTER TABLE `band_members` DISABLE KEYS */;
INSERT INTO `band_members` VALUES (1,1,3,'Voz principal','LEADER','2026-07-28 16:48:50'),(2,1,7,'Guitarra principal','MEMBER','2026-07-28 16:48:50'),(3,1,8,'Teclado','MEMBER','2026-07-28 16:48:50'),(4,2,4,'Sintetizadores','LEADER','2026-07-28 16:48:50'),(5,2,9,'Bateria electronica','MEMBER','2026-07-28 16:48:50'),(6,2,10,'Bajo','MEMBER','2026-07-28 16:48:50'),(7,3,5,'Guitarra ritmica','LEADER','2026-07-28 16:48:50'),(8,3,11,'Bateria','MEMBER','2026-07-28 16:48:50'),(9,3,12,'Coros','MEMBER','2026-07-28 16:48:50');
/*!40000 ALTER TABLE `band_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bands`
--

DROP TABLE IF EXISTS `bands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bands` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `leader_user_id` bigint NOT NULL,
  `name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invite_code` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invite_code` (`invite_code`),
  KEY `idx_bands_leader_user_id` (`leader_user_id`),
  CONSTRAINT `fk_bands_leader_users` FOREIGN KEY (`leader_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bands`
--

LOCK TABLES `bands` WRITE;
/*!40000 ALTER TABLE `bands` DISABLE KEYS */;
INSERT INTO `bands` VALUES (1,3,'Luna Session Band','Banda de apoyo para shows de Luna Vale.','LUNA-2026-AURA','2026-07-28 16:48:50','2026-07-28 16:48:50'),(2,4,'Neon River Live','Formato en vivo de Neon River con musicos invitados.','NEON-2026-AURA','2026-07-28 16:48:50','2026-07-28 16:48:50'),(3,5,'Atlas Nova Crew','Agrupacion indie para repertorios electricos.','ATLAS-2026-AURA','2026-07-28 16:48:50','2026-07-28 16:48:50');
/*!40000 ALTER TABLE `bands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyway_schema_history`
--

DROP TABLE IF EXISTS `flyway_schema_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `flyway_schema_history` (
  `installed_rank` int NOT NULL,
  `version` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `script` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checksum` int DEFAULT NULL,
  `installed_by` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `installed_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `execution_time` int NOT NULL,
  `success` tinyint(1) NOT NULL,
  PRIMARY KEY (`installed_rank`),
  KEY `flyway_schema_history_s_idx` (`success`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyway_schema_history`
--

LOCK TABLES `flyway_schema_history` WRITE;
/*!40000 ALTER TABLE `flyway_schema_history` DISABLE KEYS */;
INSERT INTO `flyway_schema_history` VALUES (1,'1','create tables','SQL','V1__create_tables.sql',-1297622666,'auramusic','2026-07-28 16:48:05',2303,1),(2,'2','expand auramusic domain','SQL','V2__expand_auramusic_domain.sql',1082447595,'auramusic','2026-07-28 16:48:08',2069,1),(3,'3','remove artist verified','SQL','V3__remove_artist_verified.sql',1285848899,'auramusic','2026-07-28 16:48:08',217,1),(4,'4','simplify song metadata','SQL','V4__simplify_song_metadata.sql',-988788312,'auramusic','2026-07-29 02:24:18',1573,1),(5,'5','add user phone','SQL','V5__add_user_phone.sql',-831803825,'auramusic','2026-07-29 02:24:19',383,1),(6,'6','add artist owner','SQL','V6__add_artist_owner.sql',1343130355,'auramusic','2026-07-29 02:24:20',474,1);
/*!40000 ALTER TABLE `flyway_schema_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `token_hash` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` timestamp NOT NULL,
  `used` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token_hash` (`token_hash`),
  KEY `idx_password_reset_tokens_user_id` (`user_id`),
  KEY `idx_password_reset_tokens_expires_at` (`expires_at`),
  CONSTRAINT `fk_password_reset_tokens_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `playlist_songs`
--

DROP TABLE IF EXISTS `playlist_songs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `playlist_songs` (
  `playlist_id` bigint NOT NULL,
  `song_id` bigint NOT NULL,
  `position` int NOT NULL,
  `added_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`playlist_id`,`song_id`),
  UNIQUE KEY `uq_playlist_songs_position` (`playlist_id`,`position`),
  KEY `idx_playlist_songs_song_id` (`song_id`),
  CONSTRAINT `fk_playlist_songs_playlists` FOREIGN KEY (`playlist_id`) REFERENCES `playlists` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_playlist_songs_songs` FOREIGN KEY (`song_id`) REFERENCES `songs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ck_playlist_songs_position_positive` CHECK ((`position` > 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `playlist_songs`
--

LOCK TABLES `playlist_songs` WRITE;
/*!40000 ALTER TABLE `playlist_songs` DISABLE KEYS */;
INSERT INTO `playlist_songs` VALUES (1,3,1,'2026-07-28 16:48:50'),(1,4,2,'2026-07-28 16:48:50'),(1,11,3,'2026-07-28 16:48:50'),(2,1,1,'2026-07-28 16:48:50'),(2,2,2,'2026-07-28 16:48:50'),(2,7,3,'2026-07-28 16:48:50'),(3,12,2,'2026-07-28 16:48:50'),(3,14,1,'2026-07-28 16:48:50'),(4,8,1,'2026-07-28 16:48:50'),(4,13,2,'2026-07-28 16:48:50'),(5,5,1,'2026-07-28 16:48:50'),(5,15,2,'2026-07-28 16:48:50'),(6,3,1,'2026-07-28 16:48:50'),(6,11,2,'2026-07-28 16:48:50'),(6,14,3,'2026-07-28 16:48:50'),(7,1,1,'2026-07-28 16:48:50'),(7,6,2,'2026-07-28 16:48:50'),(8,9,1,'2026-07-28 16:48:50'),(8,10,2,'2026-07-28 16:48:50'),(9,4,1,'2026-07-28 16:48:50'),(9,12,2,'2026-07-28 16:48:50'),(10,7,2,'2026-07-28 16:48:50'),(10,15,1,'2026-07-28 16:48:50');
/*!40000 ALTER TABLE `playlist_songs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `playlists`
--

DROP TABLE IF EXISTS `playlists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `playlists` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cover_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `public` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_playlists_user_name` (`user_id`,`name`),
  KEY `idx_playlists_user_id` (`user_id`),
  CONSTRAINT `fk_playlists_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `playlists`
--

LOCK TABLES `playlists` WRITE;
/*!40000 ALTER TABLE `playlists` DISABLE KEYS */;
INSERT INTO `playlists` VALUES (1,7,'Dark Glass Coding','Musica para programar interfaces de noche.','https://images.auramusic.local/playlists/dark-glass-coding.png',1,'2026-07-28 16:48:50','2026-07-28 16:48:50'),(2,8,'Pop Para La Tarde','Canciones ligeras para escuchar despues de clases.','https://images.auramusic.local/playlists/pop-tarde.png',1,'2026-07-28 16:48:50','2026-07-28 16:48:50'),(3,9,'Beats En Camino','Tracks con ritmo para moverse por la ciudad.','https://images.auramusic.local/playlists/beats-camino.png',1,'2026-07-28 16:48:50','2026-07-28 16:48:50'),(4,10,'Aura Chill','Sonidos tranquilos para cerrar el dia.','https://images.auramusic.local/playlists/aura-chill.png',1,'2026-07-28 16:48:50','2026-07-28 16:48:50'),(5,11,'Lofi Alternativo','Mezcla suave de indie, dream pop y folk.','https://images.auramusic.local/playlists/lofi-alternativo.png',0,'2026-07-28 16:48:50','2026-07-28 16:48:50'),(6,12,'Hits AuraMusic','Seleccion de canciones populares de la plataforma.','https://images.auramusic.local/playlists/hits-auramusic.png',1,'2026-07-28 16:48:50','2026-07-28 16:48:50'),(7,1,'Revision QA','Playlist de prueba para revisar comportamiento del backend.','https://images.auramusic.local/playlists/revision-qa.png',0,'2026-07-28 16:48:50','2026-07-28 16:48:50'),(8,2,'Novedades Staff','Canciones destacadas por administradores.','https://images.auramusic.local/playlists/novedades-staff.png',1,'2026-07-28 16:48:50','2026-07-28 16:48:50'),(9,7,'Electronic Focus','Electronica y dance pop para concentrarse.','https://images.auramusic.local/playlists/electronic-focus.png',1,'2026-07-28 16:48:50','2026-07-28 16:48:50'),(10,8,'Domingo Acustico','Folk y pop tranquilo para descansar.','https://images.auramusic.local/playlists/domingo-acustico.png',1,'2026-07-28 16:48:50','2026-07-28 16:48:50');
/*!40000 ALTER TABLE `playlists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revoked_tokens`
--

DROP TABLE IF EXISTS `revoked_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revoked_tokens` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `token_hash` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` timestamp NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token_hash` (`token_hash`),
  KEY `idx_revoked_tokens_expires_at` (`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revoked_tokens`
--

LOCK TABLES `revoked_tokens` WRITE;
/*!40000 ALTER TABLE `revoked_tokens` DISABLE KEYS */;
INSERT INTO `revoked_tokens` VALUES (1,'7fa658c0e5c715d3610776f61717804e18770e2b8be2eedbdea9a431f93a451e','2026-07-28 18:37:34','2026-07-28 18:00:53');
/*!40000 ALTER TABLE `revoked_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'ADMIN','Administrador con acceso completo a la plataforma','2026-07-28 16:48:50'),(2,'MUSICIAN','Musico integrante de banda con acceso a repertorios compartidos','2026-07-28 16:48:50'),(3,'SOLO','Musico solista con biblioteca y repertorios propios','2026-07-28 16:48:50');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `setlist_items`
--

DROP TABLE IF EXISTS `setlist_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `setlist_items` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `setlist_id` bigint NOT NULL,
  `song_id` bigint NOT NULL,
  `position` int NOT NULL,
  `transpose_steps` int NOT NULL DEFAULT '0',
  `break_seconds` int NOT NULL DEFAULT '0',
  `notes` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_setlist_items_position` (`setlist_id`,`position`),
  KEY `idx_setlist_items_song_id` (`song_id`),
  CONSTRAINT `fk_setlist_items_setlists` FOREIGN KEY (`setlist_id`) REFERENCES `setlists` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_setlist_items_songs` FOREIGN KEY (`song_id`) REFERENCES `songs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ck_setlist_items_break_non_negative` CHECK ((`break_seconds` >= 0)),
  CONSTRAINT `ck_setlist_items_position_positive` CHECK ((`position` > 0)),
  CONSTRAINT `ck_setlist_items_transpose_range` CHECK ((`transpose_steps` between -(12) and 12))
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `setlist_items`
--

LOCK TABLES `setlist_items` WRITE;
/*!40000 ALTER TABLE `setlist_items` DISABLE KEYS */;
INSERT INTO `setlist_items` VALUES (1,1,1,1,0,15,'Abrir con luces bajas','2026-07-28 16:48:51'),(2,1,2,2,1,30,'Subir un semitono para la voz invitada','2026-07-28 16:48:51'),(3,1,7,3,0,45,'Presentar a la banda antes del coro','2026-07-28 16:48:51'),(4,2,3,1,0,10,'Entrada con click track','2026-07-28 16:48:51'),(5,2,4,2,-1,20,'Transicion directa','2026-07-28 16:48:51'),(6,2,11,3,0,30,'Final extendido','2026-07-28 16:48:51'),(7,3,5,1,0,20,'Afinacion estandar','2026-07-28 16:48:51'),(8,3,6,2,2,30,'Version mas brillante','2026-07-28 16:48:51'),(9,3,10,3,0,60,'Pausa para cambio de guitarra','2026-07-28 16:48:51'),(10,4,15,1,0,15,'Inicio acustico','2026-07-28 16:48:51'),(11,4,13,2,-2,30,'Tono mas comodo','2026-07-28 16:48:51'),(12,4,8,3,0,45,'Cierre con coros','2026-07-28 16:48:51'),(13,1,15,4,0,0,NULL,'2026-07-28 17:40:10');
/*!40000 ALTER TABLE `setlist_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `setlists`
--

DROP TABLE IF EXISTS `setlists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `setlists` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `owner_user_id` bigint NOT NULL,
  `band_id` bigint DEFAULT NULL,
  `name` varchar(140) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_setlists_owner_name` (`owner_user_id`,`name`),
  KEY `idx_setlists_band_id` (`band_id`),
  CONSTRAINT `fk_setlists_bands` FOREIGN KEY (`band_id`) REFERENCES `bands` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_setlists_owner_users` FOREIGN KEY (`owner_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `setlists`
--

LOCK TABLES `setlists` WRITE;
/*!40000 ALTER TABLE `setlists` DISABLE KEYS */;
INSERT INTO `setlists` VALUES (1,3,1,'Show Electrico Luna','Repertorio principal para concierto nocturno.','2026-07-29','2026-07-28 16:48:51','2026-07-28 16:48:51'),(2,4,2,'Neon Club Session','Set electronico para evento en club.','2026-08-02','2026-07-28 16:48:51','2026-07-28 16:48:51'),(3,5,3,'Atlas Indie Night','Setlist indie rock con pausas cortas.','2026-08-09','2026-07-28 16:48:51','2026-07-28 16:48:51'),(4,12,NULL,'Camila Solo Acustico','Repertorio personal de musico solista.','2026-08-16','2026-07-28 16:48:51','2026-07-28 16:48:51');
/*!40000 ALTER TABLE `setlists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `songs`
--

DROP TABLE IF EXISTS `songs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `songs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `artist_id` bigint NOT NULL,
  `owner_user_id` bigint DEFAULT NULL,
  `album` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lyrics` text COLLATE utf8mb4_unicode_ci,
  `duration_seconds` int NOT NULL,
  `genre` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `original_key` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bpm` int DEFAULT NULL,
  `explicit_content` tinyint(1) NOT NULL DEFAULT '0',
  `play_count` bigint NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_songs_artist_id` (`artist_id`),
  KEY `idx_songs_owner_user_id` (`owner_user_id`),
  CONSTRAINT `fk_songs_artists` FOREIGN KEY (`artist_id`) REFERENCES `artists` (`id`),
  CONSTRAINT `fk_songs_owner_users` FOREIGN KEY (`owner_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `ck_songs_bpm_positive` CHECK (((`bpm` is null) or (`bpm` > 0))),
  CONSTRAINT `ck_songs_duration_positive` CHECK ((`duration_seconds` > 0)),
  CONSTRAINT `ck_songs_play_count_non_negative` CHECK ((`play_count` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `songs`
--

LOCK TABLES `songs` WRITE;
/*!40000 ALTER TABLE `songs` DISABLE KEYS */;
INSERT INTO `songs` VALUES (1,1,3,'Noche Cristal','Cristal Azul','[VERSO]\n[G]Luz sobre el mar\n[Em]brilla al despertar\n[CORO]\n[C]Cristal azul\n[D]me guia tu voz',214,'Pop','G',116,0,12450,'2026-07-28 16:48:50','2026-07-29 02:24:17'),(2,1,3,'Noche Cristal','Luces en Silencio','[VERSO]\n[Am]Calles sin final\n[F]luces al pasar\n[CORO]\n[C]Todo vuelve a sonar\n[G]si te quedas aca',198,'Pop','C',104,0,9800,'2026-07-28 16:48:50','2026-07-29 02:24:17'),(3,2,4,'Electric Delta','Delta Neon','[INTRO]\n[Dm]Pulso digital\n[Bb]noche artificial\n[CORO]\n[F]Delta neon\n[C]enciende la ciudad',243,'Electronica','Dm',128,0,20230,'2026-07-28 16:48:50','2026-07-29 02:24:17'),(4,2,4,'Electric Delta','Circuitos','[VERSO]\n[Em]Corre la senal\n[C]no puedo parar\n[CORO]\n[G]Circuitos de luz\n[D]me llevan a ti',226,'Electronica','Em',122,0,17590,'2026-07-28 16:48:50','2026-07-29 02:24:17'),(5,3,5,'Orbita Interior','Gravedad Cero','[VERSO]\n[A]Subo sin mirar\n[F#m]dejo de pesar\n[CORO]\n[D]Gravedad cero\n[E]vuelvo a respirar',251,'Indie Rock','A',98,0,8420,'2026-07-28 16:48:50','2026-07-29 02:24:17'),(6,3,5,'Orbita Interior','Mapa Lunar','[VERSO]\n[C]Trazo una senal\n[Am]sobre el vendaval\n[CORO]\n[F]Mapa lunar\n[G]para regresar',233,'Indie Rock','C',92,0,7630,'2026-07-28 16:48:50','2026-07-29 02:24:17'),(7,4,6,'Raiz Dorada','Sol de Enero','[VERSO]\n[D]Sol de enero\n[Bm]sobre mi piel\n[CORO]\n[G]Canta la raiz\n[A]vuelve a crecer',207,'Latin Pop','D',112,0,14320,'2026-07-28 16:48:50','2026-07-29 02:24:17'),(8,4,6,'Raiz Dorada','Raiz','[VERSO]\n[Am]Vengo del sur\n[F]con fuego y luz\n[CORO]\n[C]Raiz de mi voz\n[G]late en tu cancion',219,'Soul','Am',86,0,11110,'2026-07-28 16:48:50','2026-07-29 02:24:17'),(9,5,7,'Puerto Invisible','Muelle Fantasma','[VERSO]\n[Em]Muelle sin final\n[C]barcos al azar\n[CORO]\n[G]Fantasma del mar\n[D]no me dejes atras',245,'Alternative','Em',90,0,6510,'2026-07-28 16:48:50','2026-07-29 02:24:17'),(10,6,8,'Northern Velvet','Soft Thunder','[VERSO]\n[E]Soft thunder rain\n[C#m]falling again\n[CORO]\n[A]Hold the night\n[B]turn on the light',230,'Soft Rock','E',96,0,7290,'2026-07-28 16:48:50','2026-07-29 02:24:17'),(11,7,9,'Solar Club','Club Solar','[VERSO]\n[F]Brilla el lugar\n[Dm]no quiero parar\n[CORO]\n[Bb]Club solar\n[C]vamos a bailar',204,'Dance Pop','F',124,0,18880,'2026-07-28 16:48:50','2026-07-29 02:24:17'),(12,7,9,'Solar Club','Verano Digital','[VERSO]\n[G]Verano digital\n[Em]playa virtual\n[CORO]\n[C]Sube la senal\n[D]no mires atras',216,'Dance Pop','G',126,0,15940,'2026-07-28 16:48:50','2026-07-29 02:24:17'),(13,8,10,'Bloom After Midnight','Flor Nocturna','[VERSO]\n[Bm]Flor nocturna\n[G]cerca de mi\n[CORO]\n[D]Abre tu luz\n[A]dejame seguir',260,'Dream Pop','Bm',80,0,5330,'2026-07-28 16:48:50','2026-07-29 02:24:17'),(14,9,11,'Beat District','Distrito Bajo','[VERSO]\n[Cm]Distrito bajo\n[Ab]suena en la estacion\n[CORO]\n[Eb]Sube el bajo\n[Bb]late el corazon',192,'Trap','Cm',140,1,22100,'2026-07-28 16:48:50','2026-07-29 02:24:17'),(15,10,12,'Campos de Aurora','Camino Aurora','[INTRODUCCIÓN / DANZÓN LENTO]\n[Dm] [Gm7] [C7] [Fmaj7]\n[Bbmaj7] [A7] [Dm]\n\n[VERSO 1]\n[Dm]Luz roja es la [Gm7]luz\n[C7]luz de ne[Fmaj7]ón\n[Bbmaj7]que anuncia el lu[A7]gar\n[Dm]Kumbala bar\n[Dm]Y adentro la noche [Gm7]es\n[C7]música y pa[Fmaj7]sión\n[Bbmaj7]Kumbala [A7]bar [Dm]\n\n[VERSO 2]\n[Dm]Parejas bailando en la os[Gm7]curidad\n[C7]sabor a sudor y cer[Fmaj7]veza\n[Bbmaj7]en el Kumbala [A7]bar\n[Dm]Y una pareja allá en el rin[Gm7]cón\n[C7]se aman en si[Fmaj7]lencio\n[Bbmaj7]en el Kumbala [A7]bar [Dm]\n\n[PUENTE INSTRUMENTAL / SOLO DE SAXOFÓN]\n[Dm] [Gm7] [C7] [Fmaj7]\n[Bbmaj7] [A7] [Dm]\n\n[SECCIÓN RÁPIDA / MAMBO - SKA]\n(El ritmo acelera drásticamente a un tiempo rápido con metales y percusión)\n[Dm] [A7] [Dm] [A7]\n[Dm] [C] [Bb] [A7]\n\n[OUTRO / DANZÓN FINAL]\n(El tempo vuelve a caer al ritmo lento del inicio para el desvanecimiento)\n[Dm] [Gm7] [C7] [Fmaj7]\n[Bbmaj7] [A7] [Dm]',238,'Folk','D',78,0,6890,'2026-07-28 16:48:50','2026-07-29 02:24:17');
/*!40000 ALTER TABLE `songs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `role_id` bigint NOT NULL,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_users_role_id` (`role_id`),
  CONSTRAINT `fk_users_roles` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,1,'admin.noe','admin@auramusic.local',NULL,'$2a$10$gHjVfC8g3seYKhccvAADP.4MNg.0j8bvw4NpW.S9H1awRHh6I4Dmm','Noe Admin','https://images.auramusic.local/avatars/admin-noe.png',1,'2026-07-28 16:48:50','2026-07-28 16:48:50'),(2,1,'admin.ops','admin.ops@auramusic.local',NULL,'$2a$10$D5QC3XzN5By1xHP8xeIvQepKAsupbPul.krHwVu8mWuHzoLt3ik2G','Aura Ops','https://images.auramusic.local/avatars/admin-ops.png',1,'2026-07-28 16:48:50','2026-07-28 16:48:50'),(3,2,'luna.vale','luna.vale@auramusic.local',NULL,'$2a$10$D5QC3XzN5By1xHP8xeIvQepKAsupbPul.krHwVu8mWuHzoLt3ik2G','Luna Vale','https://images.auramusic.local/avatars/luna-vale.png',1,'2026-07-28 16:48:50','2026-07-28 16:48:50'),(4,2,'neon.river','neon.river@auramusic.local',NULL,'$2a$10$D5QC3XzN5By1xHP8xeIvQepKAsupbPul.krHwVu8mWuHzoLt3ik2G','Neon River','https://images.auramusic.local/avatars/neon-river.png',1,'2026-07-28 16:48:50','2026-07-28 16:48:50'),(5,2,'atlas.nova','atlas.nova@auramusic.local',NULL,'$2a$10$D5QC3XzN5By1xHP8xeIvQepKAsupbPul.krHwVu8mWuHzoLt3ik2G','Atlas Nova','https://images.auramusic.local/avatars/atlas-nova.png',1,'2026-07-28 16:48:50','2026-07-28 16:48:50'),(6,2,'maya.sol','maya.sol@auramusic.local',NULL,'$2a$10$D5QC3XzN5By1xHP8xeIvQepKAsupbPul.krHwVu8mWuHzoLt3ik2G','Maya Sol','https://images.auramusic.local/avatars/maya-sol.png',1,'2026-07-28 16:48:50','2026-07-28 16:48:50'),(7,3,'diego.ui','diego.ui@auramusic.local',NULL,'$2a$10$D5QC3XzN5By1xHP8xeIvQepKAsupbPul.krHwVu8mWuHzoLt3ik2G','Diego UI','https://images.auramusic.local/avatars/diego-ui.png',1,'2026-07-28 16:48:50','2026-07-28 16:48:50'),(8,3,'sofia.beats','sofia.beats@auramusic.local',NULL,'$2a$10$D5QC3XzN5By1xHP8xeIvQepKAsupbPul.krHwVu8mWuHzoLt3ik2G','Sofia Beats','https://images.auramusic.local/avatars/sofia-beats.png',1,'2026-07-28 16:48:50','2026-07-28 16:48:50'),(9,3,'mateo.mix','mateo.mix@auramusic.local',NULL,'$2a$10$D5QC3XzN5By1xHP8xeIvQepKAsupbPul.krHwVu8mWuHzoLt3ik2G','Mateo Mix','https://images.auramusic.local/avatars/mateo-mix.png',1,'2026-07-28 16:48:50','2026-07-28 16:48:50'),(10,3,'valeria.wave','valeria.wave@auramusic.local',NULL,'$2a$10$D5QC3XzN5By1xHP8xeIvQepKAsupbPul.krHwVu8mWuHzoLt3ik2G','Valeria Wave','https://images.auramusic.local/avatars/valeria-wave.png',1,'2026-07-28 16:48:50','2026-07-28 16:48:50'),(11,3,'andres.lofi','andres.lofi@auramusic.local',NULL,'$2a$10$D5QC3XzN5By1xHP8xeIvQepKAsupbPul.krHwVu8mWuHzoLt3ik2G','Andres Lofi','https://images.auramusic.local/avatars/andres-lofi.png',1,'2026-07-28 16:48:50','2026-07-28 16:48:50'),(12,3,'camila.pop','camila.pop@auramusic.local',NULL,'$2a$10$D5QC3XzN5By1xHP8xeIvQepKAsupbPul.krHwVu8mWuHzoLt3ik2G','Camila Pop','https://images.auramusic.local/avatars/camila-pop.png',1,'2026-07-28 16:48:50','2026-07-28 16:48:50'),(14,2,'lola','lola@gmail.com',NULL,'$2a$10$i6TKS18CD0EAQCu4ze9fwuQQUdX0p2ZvIonMWvXbs2m6OqSve24eG','Lola',NULL,1,'2026-07-29 01:07:03','2026-07-29 01:07:03'),(15,2,'edwinnoe','chavwzedwin@gmail.com','+529511095153','$2a$10$XTott7OZ4lOrrceRZXfEBu4vnMKsCk7xnIQjwkQ6tKrRQpC7OXXJm','Bruno Musician',NULL,1,'2026-07-29 02:30:38','2026-07-29 02:30:38');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'auramusic'
--

--
-- Dumping routines for database 'auramusic'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-29  4:18:33
